package com.company;

import javax.sound.midi.Soundbank;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Deposit deposit = new Deposit();
        AccountInfo accountInfo = new AccountInfo();
        Withdraw withdraw= new Withdraw();
        Functions functions = new Functions();
        Balance balance = new Balance();
        int choice;



        System.out.println("Welcome to The Bank!");
        boolean bool = false;
        while (!bool){
            System.out.println("Enter the 10 digit Account Number: ");
            accountInfo.accountNumber = sc.nextLong();
            if (Long.toString(accountInfo.accountNumber).length()>10){
                bool =true;
            }else {
                System.out.println(" Oops !!  Invalid Account Number!!");
            }
        }
        System.out.println("Hello " + accountInfo.accountHolderName +" Please select the desired option "+ "\n "+ " 1 for Deposit money" + "\n" + " 2 for Withdraw money "+"\n "+ " 3 for Check Balance");
        choice = sc.nextInt();
        if (choice == 1){
            System.out.println("Enter a deposit amount");
            deposit.depositMoney(deposit.depositAmount =sc.nextInt(),balance.currentBalance);
            deposit.isDeposit =true;
            System.out.println(balance.checkBal());
        }else if (choice==2){
            System.out.println("Enter the withdraw amount");
            withdraw.withdrawMoney(withdraw.withdrawAmount = sc.nextInt(),balance.currentBalance);
            withdraw.isWithdrawal = true;
            System.out.println(balance.checkBal());
        }else if (choice==3){
            System.out.println(balance.checkBal());
        }




    }
}

class AccountInfo{
   public long accountNumber;
   public String accountHolderName = "Sreeju";
}
class Deposit{
    public int depositAmount;
    boolean isDeposit = false;

    public void depositMoney(int depAmt,int curBalance){
       // int initialBal =0;
        curBalance=0;
        if(depAmt==0){
            System.out.println("Enter a invalid amount!!");
        }else {
            curBalance += depAmt;
            System.out.println("Deposit Successful");
        }


    }
}
class Withdraw{
    public int withdrawAmount;
    //Balance afterWithdrawalBalance;
    boolean isWithdrawal = false;

    public void withdrawMoney(int withdrawAmount,int currBal){
        Balance b = new Balance();
        if (withdrawAmount<b.checkBal()){
            System.out.println("Unable to withdraw");
        }else {
            currBal-=withdrawAmount;
        }
    }

}
class Balance{
    public int initialBalance =0;
    public int currentBalance;

    public int checkBal(){
        Deposit d = new Deposit();
        Withdraw w = new Withdraw();
        if (d.isDeposit = true){
            currentBalance +=d.depositAmount;
        }else {
            currentBalance = initialBalance;
        }
      if (w.isWithdrawal = true){
          currentBalance -=w.withdrawAmount;
      }
       return currentBalance;

    }
}
class Functions{
/*
    public  void depositMoney(int depAmt,int initBal,int curBal){
        System.out.println("Enter deposit amount");
        if(depAmt<=0){
            System.out.println("Please enter a valid amount");
        }else {
            curBal= initBal + depAmt;
        System.out.println("Deposit Successful!");}
    }
    public  void withdrawMoney(int widAmt,int curBal){
        System.out.println("Enter Withdrawal amount:");
        if (widAmt>curBal){
            System.out.println("Insufficient balance!!");
        }else
            curBal-=widAmt;
    }
    public  void checkBalance(){
        Balance balance = new Balance();
        System.out.println(balance.currentBalance);
    }
    public void ValidateAccNo(String accountNumber){

*/
        }


